﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{


    public static class ExtensionMethod {

        public static IEnumerable<Kupac> fromTown(
            this List<Kupac> source, Func<Kupac, bool> predicate)
        {
            return (source.AsEnumerable().Where(predicate));
        }          
    
    }


    public class Kupac
    {
        public int Age;
        public int ID;
        public string Town;
        public string Name;
        public int AgeGroup;

    }

    public class Student
    {
        public string Name;
        public int AgeGroup;
    }


    public static class Program
    {



        static void Main(string[] args)
        {


          List<Kupac> Kupci = new List<Kupac>{
               
                new Kupac { Age=60, ID=2, Town= "Novi Sad", Name= "Goran " },
                new Kupac { Age=50, ID=3, Town= "Becej", Name= "Mihajlo " },
                new Kupac { Age=34, ID=4, Town= "Sombor", Name= "Bogdan" },
                new Kupac { Age=19, ID=1, Town= "Beograd", Name= "Borko " }
           };

         



            //PRVI ZADATAK

            //Kupac sa ID=3
          var gradjanin = from Kupac in Kupci
                                     where Kupac.ID == 3
                                     select Kupac.Name;

          gradjanin.ToList().ForEach(g => Console.WriteLine(g));

          Console.ReadLine();

         

            //gradjani koji nisu iz Beograda
           
         var gradjani = Kupci.fromTown(t => t.Town != "Beograd");

         gradjani.ToList().ForEach(g => Console.WriteLine(g.Name));


         Console.ReadLine();


        //Listanje po godinama - od najstarijeg do najmladjeg
         var godine = from Kupac in Kupci
                         orderby Kupac.Age descending
                         select Kupac;


         godine.ToList().ForEach(n => Console.WriteLine(n.Name));


         Console.ReadLine();

         //Najmladji
         var najmladji = from Kupac in Kupci
                         where Kupac.Age == Kupci.Min(k => k.Age)
                         select Kupac.Name;

         najmladji.ToList().ForEach(j => Console.WriteLine(j));

         Console.ReadLine();

        //Punoletni i imaju manje od 50
         var osobe = from Kupac in Kupci
                     where Kupac.Age > 18 && Kupac.Age < 50
                     select Kupac.Name;

         osobe.ToList().ForEach(o => Console.WriteLine(o));

         Console.ReadLine();


        //Sadrzi slovo a
         var ljudi = from Kupac in Kupci
                     where  Kupac.Name.Contains("a")
                     select Kupac.Name;

         ljudi.ToList().ForEach(l => Console.WriteLine(l));

         Console.ReadLine();

         //NE Sadrzi slovo i
           var xxx = from Kupac in Kupci
                     where !Kupac.Name.Contains("i")
                     select Kupac.Name;

         xxx.ToList().ForEach(y => Console.WriteLine(y));

         Console.ReadLine();



            //DRUGI ZADATAK-Iz primera Fluent sintaksu prebaciti u LINQ sintaksu>


           //  var orderByResult = from student in Studenti
               //              orderby student.Name, student.Age
                //             select student;
                                

            //TRECI ZADATAK- Grupisi studente po godinama

         List<Student> Studenti = new List<Student>{
               
                new Student { AgeGroup=18,Name= "John" },
                new Student { AgeGroup=18, Name= "Steve" },
                new Student { AgeGroup=21, Name= "Ron" }
           };


         var students = from s in Studenti
                        group s.Name by s.AgeGroup into g
                        select new { AgeGroup = g.Key, Name = String.Join(", ", g.ToList()) };
                            

            students.ToList().ForEach(g => Console.WriteLine(g));

            Console.ReadLine();
                           


            // 4.ZADATAK -

            string[] Names = { "Bojana", "Ivana", "Draga", "Milica", "Tina" };

          
            IEnumerable<string> query = Names
            .Where(n => n.Contains("i") || n.Contains("I"))
            .OrderByDescending (n => n.Length) 
            .Select (n => n.ToUpper());
            foreach (string name in query)
            Console.Write (name + " " );
            Console.ReadLine();
            // REZULTAT: MILICA> IVANA> TINA



          //  var letter = Names.Where(str => str.ToLower().Equals("I"));
          //  Console.WriteLine();
          //  Console.ReadLine();

            //var ime = from names 
            //            where imena.names.contains("a")
            //            select ime.name;

            //ime.tolist().foreach(l => console.writeline(l));

            



        }
    }
}
