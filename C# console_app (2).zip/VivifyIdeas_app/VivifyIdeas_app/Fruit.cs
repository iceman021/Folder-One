﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivifyIdeas_app
{
    class Fruit
    {
        public string name { get; set; }

        public BuyingPlace buyingPlace { get; set; }

        public decimal priceValue { get; set; }
        
        public Enums.FruitClass fruitCategory { get; set; }
    }
}
