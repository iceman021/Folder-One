﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivifyIdeas_app
{
    class Packaging
    {
        private static int quantity = 100;

        public void getPackagingQuantity(int quantityNum)
        {
            if (quantityNum > quantity)
            {
                throw new Exception("Kolicina trazene ambalaze nije dostupna");
            }

            quantity = quantity - quantityNum;
        }

        public void returnPackagingQuantity(int quantityNum)
        {
            quantity = quantity + quantityNum;
        }

        //This is just for testing
        public int getQuantity()
        {
            return quantity;
        }
    }
}
