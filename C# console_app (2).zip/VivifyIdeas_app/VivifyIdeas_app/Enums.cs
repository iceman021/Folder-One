﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivifyIdeas_app
{
    public class Enums
    {
        public enum FruitClass
        {
            firstClass = 0,
            secondClass = 1,
            thirdClass = 2
        }
    }
}
