﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivifyIdeas_app
{
    class Producer
    {
        public string firstName { get; set; }

        public string lastName { get; set; }

        public long jmbg { get; set; }

        public string phoneNumber { get; set; }

        public string taxStatement { get; set; }

        public string contract { get; set; }

        public double plotArea { get; set; }

        public string currentAccount { get; set; }

        public BuyingPlace buyingPlace { get; set; }
    }
}
