﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivifyIdeas_app
{
    class Ransom
    {
        public int documentID { get; set; }

        public decimal quantity { get; set; }

        public int quantityOFObligated { get; set; }

        public int quantityOFReturned { get; set; }
    }
}
