﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace VivifyIdeas_app
{
    class ColdStorage: IColdStorage
    {
        const string filePath = "..\\..\\..\\logfile.txt";

        public void doTheBuying()
        {
            /*Unos otkupnog mesta i proizvodjaca*/
            /*-------------------------------------------------------*/
            
            BuyingPlace buyingPlace_Futoska = new BuyingPlace();
            buyingPlace_Futoska.placeName = "Futoska pijaca";

            Producer buyerDusan = new Producer();
            buyerDusan.firstName = "Dusan";
            buyerDusan.lastName = "Vukoje";
            buyerDusan.jmbg = 1234567891234;
            buyerDusan.phoneNumber = "021/123-456";
            buyerDusan.taxStatement = "Poreska izjava br. 1 ...";
            buyerDusan.contract = "Ugovor 1 ...";
            buyerDusan.plotArea = 10.20;
            buyerDusan.currentAccount = "3545343218-1165";
            buyerDusan.buyingPlace = null;
            buyingPlace_Futoska.buyer = buyerDusan;

            logToFile("Unos otkupnog mesta");
            logToFile("Unos proizvođača");

            /*Unos voća*/
            /*-------------------------------------------------------*/

            Fruit banana = new Fruit();
            banana.name = "Banana";
            banana.buyingPlace = buyingPlace_Futoska;
            banana.priceValue = 120;
            banana.fruitCategory = Enums.FruitClass.secondClass;

            logToFile("Unos voća");

            /*Unos zaduženja ambalaže*/
            /*-------------------------------------------------------*/

            Console.WriteLine("Unesite koliko komada ambalaze zelite: ");
            int packageDept = 0;
            try
            {
                packageDept = Int32.Parse(Console.ReadLine());
            }
            catch (Exception)
            {
                Console.WriteLine("Morate uneti ceo broj");
                throw;
            }

            Packaging packaging1 = new Packaging();
            try
            {
                //Console.WriteLine(packaging1.getQuantity());
                packaging1.getPackagingQuantity(packageDept);
                //Console.WriteLine(packaging1.getQuantity());
                Console.WriteLine("Uzeto " + packageDept.ToString() + " komada ambalaze.");
            }
            catch (Exception)
            {
                Console.WriteLine("Kolicina trazene ambalaze nije dostupna");
                throw;
            }

            logToFile("Unos zaduženja ambalaže");

            /*Unos otkupa voća i pregled otkupa*/
            /*-------------------------------------------------------*/

            Document document = Document.Instance;
            var documentNumber = document.getDocumentNumber();

            Console.WriteLine("Broj dokumenta je " + documentNumber.ToString());

            Console.WriteLine("Unesite koliko komada voca '" + banana.name + "' zelite.");
            var handedFruitAmount = Int32.Parse(Console.ReadLine());
            packaging1.returnPackagingQuantity(packageDept - handedFruitAmount);
            Console.WriteLine("Zaduzena ambalaza: " + handedFruitAmount.ToString());
            Console.WriteLine("Vracena ambalaza: " + (packageDept - handedFruitAmount).ToString());
            Console.WriteLine("Trenutno stanje ambalaza: " + packaging1.getQuantity().ToString());


            logToFile("Unos otkupa voća");
            logToFile("Pregled otkupa");

            /*Pregled salda za otkupno mesto*/
            /*-------------------------------------------------------*/

            Console.WriteLine("Saldo za otkupno mesto: " + (handedFruitAmount * banana.priceValue).ToString() + " rsd");

            logToFile("Pregled salda za otkupno mesto");

            Console.ReadLine();
        }

        static void logToFile(string action)
        {
            if (!String.IsNullOrWhiteSpace(action))
            {
                // Create a writer and open the file:
                StreamWriter log;

                if (!File.Exists(filePath))
                {
                    log = new StreamWriter(filePath);
                }
                else
                {
                    log = File.AppendText(filePath);
                }

                // Write to the file:
                log.WriteLine("[" + DateTime.Now.Date.ToString("MMMM dd, yyyy") + "]" + "[" + DateTime.Now.TimeOfDay + "]" + "[" + action + "]");

                // Close the stream:
                log.Close();
            }
        }
    }
}
