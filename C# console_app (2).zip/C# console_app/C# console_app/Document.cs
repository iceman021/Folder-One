﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VivifyIdeas_app
{
    public sealed class Document
    {
        private static Document instance = null;

        private Document()
        {
        }

        public static Document Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Document();    
                }
                instance.documentNumber++;

                return instance;
            }
        }

        private int documentNumber = 0;

        public int getDocumentNumber()
        {
            return documentNumber;
        }
       
    }
}
