  
  var modal = document.getElementById('modal');

  var modalBtn = document.getElementById('button');

  var closeBtn = document.getElementById('close')[0];


modalBtn.addEventListener('click', openModal);
/*closeBtn.addEventListener('click', closeModal);*/

  function openModal() {
  	modal.style.display = 'block';
  }

  function closeModal() {
  	modal.style.display = 'none';
  }

/*
var clr = document.getElementById('button');

	function Color() {
		button.style. = 'forestgreen';
	}
*/


  /*___________CLICK COUNTER___________*/
   

  var i = 0;
    function Count() {
        document.getElementById('likes').value = ++i;
    };


	var i = 0;

    function Count2() {
        document.getElementById('likes2').value = ++i;
    };

	var i = 0;

    function Count3() {
        document.getElementById('likes3').value = ++i;
    };

	var i = 0;

    function Count4() {
        document.getElementById('likes4').value = ++i;
    };


/*------------,MODAL-BOX Meni,--------------*/
/*
document.getElementById('button').addEventListener('click',
	function openmodal() {
	document.querySelector('.modal').style.display = 'flex';
});


	document.querySelector('.close').addEventListener('click',
	function(){
		document.querySelector('.modal').style.display = 'none';
};
*/

/*
    var cnt=0;
    function incr(){
     cnt=parseInt(cnt)+parseInt(1);
     var paragraph=document.getElementsByClassName("likes");
     likess.innerHTML=" "+cnt +"";//this part has been edited

    }
  */



/*
$(function() {
	console.log('usao sam u funkciju');
    $(".one").click(function() {
    	console.log('one je kliknut');
        var input = $(this).siblings('.link1');
        $('.one').append(input.val()) + 1;
    });

    $(".two").click(function() {
    	console.log('one je kliknut');
        var input = $(this).siblings('.link2');
        $('.two').append(input.val()) - 1;
    });
});
*/

/*
$div = document.querySelector('heart') 
$p = document.querySelector('count')
function increment(){
	$p.innerHTML++;
}
$div.addEventListener('click',increment);
*/
/*    
var div = document.getElementById("heart");

div.onclick = function() {
  this.style.backgroundColor = 'red';
};

*/


/*
    	  var count = 0;
	      var button = document.getElementById("heart");
	      var display = document.getElementsByClassName("likess");



  function clickCount() {
  count++;
}

	  
     	div.onclick = function(){
        count++;
        display.innerHTML = count;
      }

*/

/*
    <input type="button" value="Count" id="countButton" />

    <p>The button was pressed <span id="displayCount">0</span> times.</p>

      var count = 0;
      var button = document.getElementById("countButton");
      var display = document.getElementById("displayCount");

      button.onclick = function(){
        count++;
        display.innerHTML = count;
      }
*/

  /*
    var i = 0;
    function likeClick() {
        document.getElementById('inc').value = ++i;
    }
*/

  

/*

$(function(){
  $.scrollIt();
});
*/



/*-------------- reusable -----------------*/

/*
$(document).ready(function(){
	var articles = $('.articles');
	var navigation = $('nav');
	
	//when a nav link is clicked, smooth scroll to the section
	navigation.on('click', 'a', function(event){
		event.preventDefault(); //prevents previous event
		smoothScroll($(this.hash));
	});
	
	//update navigation on scroll...
	$(window).on('scroll', function(){
		updateNavigation();
	})
	//...and when the page starts
	updateNavigation();
*/	
/*

	/////FUNCTIONS
	function updateNavigation(){
		contentSection.each(function(){
			var sectionName = $(this).attr('id');
			var navigationMatch = $('nav a[href="#' + sectionName + '"]');
			if( ($(this).offset().top - $(window).height()/2 < $(window).scrollTop()) &&
				  ($(this).offset().top + $(this).height() - $(window).height()/2 > $(window).scrollTop()))
				{
					navigationMatch.addClass('active-section');
				}
			else {
				navigationMatch.removeClass('active-section');
			}
		});
	}
	function smoothScroll(target){
		$('body,html').animate({
			scrollTop: target.offset().top
		}, 800);
	}
});

*/



/*===============================================*/







/*
$("a[href='.wrapper']").click(function() {
  $("html, body").animate({ scrollTop: 0 }, "slow");
  return false;
});

$("a[href='.Featured']").click(function() {
  $("html, body").animate({ scrollTop: 0 }, "slow");
  return false;
});

$("a[href='.articles']").click(function() {
  $("html, body").animate({ scrollTop: 0 }, "slow");
  return false;
});

$("a[href='.gallery']").click(function() {
  $("html, body").animate({ scrollTop: 0 }, "slow");
  return false;
});

$("a[href='.footer']").click(function() {
  $("html, body").animate({ scrollTop: 0 }, "slow");
  return false;
});
*/